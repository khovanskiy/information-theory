package ru.ifmo.ctddev.khovanskiy.information.task3;

import lombok.Data;

/**
 * victor
 */
@Data
public class NoCodingResult extends AlgorithmResult {
    private int bits;
}
