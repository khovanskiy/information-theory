package ru.ifmo.ctddev.khovanskiy.information.task3;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * victor
 */
@Data
@NoArgsConstructor
public abstract class AlgorithmResult {
    private String input;
    private String output;
}
