package ru.ifmo.ctddev.khovanskiy.information.task3;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * victor
 */
@Data
@NoArgsConstructor
public class DistancesStepResult {
    private int ordinal;
    private String sequence;
    private String y;
}
